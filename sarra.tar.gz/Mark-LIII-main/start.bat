@echo off
setlocal

rem Demarre MARK LIII depuis le dossier du present fichier.
cd /d "%~dp0"

set "PYTHON=C:\Users\IA5\AppData\Local\Programs\Python\Python310\python.exe"

if exist "%PYTHON%" (
    "%PYTHON%" "%~dp0main.py"
) else (
    py -3.10 "%~dp0main.py"
)

if errorlevel 1 (
    echo.
    echo MARK LIII s'est arrete avec une erreur.
    pause
)

endlocal