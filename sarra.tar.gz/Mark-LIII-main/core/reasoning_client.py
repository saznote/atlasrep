"""Reasoning & coding brain — separate from the Gemini voice session.

Sarra's voice conversation stays on Gemini Live (``LIVE_MODEL`` in main.py),
but the brain used for reasoning and code generation (actions/code_helper.py,
actions/dev_agent.py, session summaries, …) can be pointed at any
OpenAI-compatible provider offering a free API key:

    openrouter  https://openrouter.ai/api/v1     default model: openrouter/free
    groq        https://api.groq.com/openai/v1   default model: openai/gpt-oss-120b
    cerebras    https://api.cerebras.ai/v1       default model: gpt-oss-120b
    mistral     https://api.mistral.ai/v1        default model: mistral-small-latest
    custom      any OpenAI-compatible base URL   (LM Studio, Ollama, llama.cpp…)

Configuration lives in ``config/api_keys.json``:

    "reasoning_provider": "openrouter",
    "reasoning_api_key":  "sk-or-…",
    "reasoning_model":    "",     # empty → provider default
    "reasoning_url":      ""      # only for provider "custom"

When no reasoning provider is configured the module reports
``is_configured() == False`` and callers keep their existing Gemini path —
Gemini remains the voice engine (and the fallback brain).

The Gemini-shaped shim (``get_model()``) lets legacy call sites that use
``model.generate_content(prompt).text`` switch providers with one line.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import requests


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


BASE_DIR     = _base_dir()
CONFIG_PATH  = BASE_DIR / "config" / "api_keys.json"
_TIMEOUT_S   = 180     # long generations (code) on free tiers can be slow

# provider key → display / endpoints / free-key page / default model
PROVIDERS: dict[str, dict] = {
    "openrouter": {
        "label":         "OpenRouter",
        "base_url":      "https://openrouter.ai/api/v1",
        "key_url":       "https://openrouter.ai/settings/keys",
        "free_url":      "https://openrouter.ai/collections/free-models",
        "default_model": "openrouter/free",
    },
    "groq": {
        "label":         "Groq",
        "base_url":      "https://api.groq.com/openai/v1",
        "key_url":       "https://console.groq.com/keys",
        "free_url":      "https://console.groq.com/docs/models",
        "default_model": "openai/gpt-oss-120b",
    },
    "cerebras": {
        "label":         "Cerebras",
        "base_url":      "https://api.cerebras.ai/v1",
        "key_url":       "https://cloud.cerebras.ai/",
        "free_url":      "https://inference-docs.cerebras.ai/models/overview",
        "default_model": "gpt-oss-120b",
    },
    "mistral": {
        "label":         "Mistral",
        "base_url":      "https://api.mistral.ai/v1",
        "key_url":       "https://console.mistral.ai/api-keys",
        "free_url":      "https://docs.mistral.ai/getting-started/models/models/",
        "default_model": "mistral-small-latest",
    },
    "custom": {
        "label":         "OpenAI-compatible",
        "base_url":      "",       # read from reasoning_url
        "key_url":       "",
        "free_url":      "",
        "default_model": "",
    },
}


def load_settings() -> dict:
    """Read the reasoning settings from config/api_keys.json."""
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        data = {}
    return {
        "provider": (data.get("reasoning_provider") or "").strip().lower(),
        "api_key":  (data.get("reasoning_api_key") or "").strip(),
        "model":    (data.get("reasoning_model") or "").strip(),
        "base_url": (data.get("reasoning_url") or "").strip(),
    }


def _resolve(provider: str = "", api_key: str = "", model: str = "",
             base_url: str = "") -> dict | None:
    """Merge call-site overrides with the stored config.

    Non-empty overrides win; blanks fall back to config. Returns ``None``
    when the result cannot produce a usable request (unknown/absent
    provider, missing key, missing model for ``custom``).
    """
    s = load_settings()
    provider = (provider or s["provider"]).strip().lower()
    api_key  = (api_key  or s["api_key"]).strip()
    model    = (model    or s["model"]).strip()
    base_url = (base_url or s["base_url"]).strip()
    if provider not in PROVIDERS:
        return None
    base = base_url if provider == "custom" else PROVIDERS[provider]["base_url"]
    base = base.rstrip("/")
    if base.endswith("/chat/completions"):
        base = base[: -len("/chat/completions")]
    if not base:
        return None
    if provider != "custom" and not api_key:
        return None
    model = model or PROVIDERS[provider]["default_model"]
    if not model:
        return None
    return {"provider": provider, "api_key": api_key,
            "model": model, "base_url": base}


def is_configured() -> bool:
    """True when a reasoning provider + key are available."""
    return _resolve() is not None


def _content_to_text(content) -> str:
    """OpenAI ``message.content`` may be a string or a list of parts."""
    if isinstance(content, str):
        return content.strip()
    if isinstance(content, list):
        chunks = []
        for part in content:
            if isinstance(part, dict):
                chunks.append(str(part.get("text") or ""))
            else:
                chunks.append(str(part))
        return "\n".join(chunks).strip()
    return str(content or "").strip()


def _post_chat(cfg: dict, messages: list[dict], timeout: int = _TIMEOUT_S) -> str:
    """POST one chat-completion request; return the assistant text."""
    url = cfg["base_url"] + "/chat/completions"
    headers = {"Content-Type": "application/json"}
    if cfg["api_key"]:
        headers["Authorization"] = f"Bearer {cfg['api_key']}"
    payload = {"model": cfg["model"], "messages": messages}
    try:
        r = requests.post(url, json=payload, headers=headers, timeout=timeout)
    except requests.RequestException as e:
        raise RuntimeError(f"{cfg['provider']}: cannot reach {url} ({e})") from e
    if r.status_code != 200:
        snippet = (r.text or "").replace("\n", " ")[:200]
        raise RuntimeError(f"{cfg['provider']}: HTTP {r.status_code} — {snippet}")
    try:
        msg = r.json()["choices"][0]["message"]
    except Exception as e:
        raise RuntimeError(f"{cfg['provider']}: unexpected response ({e})") from e
    text = _content_to_text(msg.get("content"))
    if not text:
        # Some reasoning models park the answer in a separate field.
        text = _content_to_text(msg.get("reasoning_content") or msg.get("reasoning"))
    if not text:
        raise RuntimeError(f"{cfg['provider']}: empty completion")
    return text


def chat(prompt: str, system: str = "", model: str = "", provider: str = "",
         api_key: str = "", base_url: str = "", timeout: int = _TIMEOUT_S) -> str:
    """One-shot text generation on the configured reasoning provider."""
    cfg = _resolve(provider, api_key, model, base_url)
    if cfg is None:
        raise RuntimeError(
            "No reasoning AI configured — Settings → IA raisonnement & codage.")
    messages: list[dict] = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    return _post_chat(cfg, messages, timeout)


class _Response:
    """Minimal stand-in for a Gemini ``GenerateContentResponse``."""

    def __init__(self, text: str):
        self.text = text


class _ReasoningModel:
    """Gemini-shaped wrapper: ``.generate_content(prompt).text``.

    Text-only: media parts (screenshots, audio) are rejected — vision call
    sites must keep using the Gemini client directly.
    """

    def __init__(self, cfg: dict):
        self._cfg = cfg

    def generate_content(self, contents, config=None, **_ignored):
        system = ""
        if config is not None:
            system = getattr(config, "system_instruction", "") or ""
            if not isinstance(system, str):
                system = str(system)
        if isinstance(contents, (list, tuple)):
            media = [c for c in contents if not isinstance(c, str)]
            if media:
                raise RuntimeError(
                    "reasoning provider is text-only — multimodal input requires Gemini")
            prompt = "\n".join(str(c) for c in contents)
        else:
            prompt = str(contents)
        messages: list[dict] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})
        return _Response(_post_chat(self._cfg, messages))


def get_model(provider: str = "", api_key: str = "", model: str = "",
              base_url: str = "") -> _ReasoningModel | None:
    """Return the reasoning shim, or ``None`` when not configured
    (callers then fall back to their Gemini path)."""
    cfg = _resolve(provider, api_key, model, base_url)
    return _ReasoningModel(cfg) if cfg else None


def test_connection(provider: str = "", api_key: str = "", model: str = "",
                    base_url: str = "") -> tuple[bool, str]:
    """Tiny live check used by the Settings 'TEST' button → (ok, message)."""
    cfg = _resolve(provider, api_key, model, base_url)
    if cfg is None:
        if not (provider or load_settings()["provider"]):
            return False, "aucune IA sélectionnée — choisissez un fournisseur"
        label = PROVIDERS.get(provider or load_settings()["provider"],
                              {}).get("label", provider)
        return False, f"clé API manquante pour {label} — collez-la puis réessayez"
    t0 = time.time()
    try:
        out = _post_chat(cfg, [{"role": "user",
                                "content": "Reply with exactly: OK"}], timeout=30)
    except RuntimeError as e:
        return False, str(e)
    dt = time.time() - t0
    label = PROVIDERS[cfg["provider"]]["label"]
    return True, f"{cfg['model']} via {label} — « {out[:40]} » en {dt:.1f}s"



