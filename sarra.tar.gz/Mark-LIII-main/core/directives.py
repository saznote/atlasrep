"""Core directives — the assistant's system prompt (core/prompt.txt).

Single source of truth for reading and writing those directives:
  * main.py loads them when the live session is built,
  * the Settings overlay ("Core Directives" button) edits them.

Saving is atomic (temp file + os.replace), so a crash mid-save can never
leave a truncated prompt — and the previous version is kept as prompt.bak.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

# Used only when prompt.txt is missing or unreadable (matches the historical
# fallback that lived in main._load_system_prompt).
FALLBACK = (
    "You are JARVIS, Tony Stark's AI assistant. "
    "Be concise, direct, and always use the provided tools to complete tasks. "
    "Never simulate or guess results — always call the appropriate tool."
)


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


def directives_path() -> Path:
    """Absolute path of the core directives file."""
    return _base_dir() / "core" / "prompt.txt"


def load_directives(path: Path | None = None) -> str:
    """Return the directives text, or FALLBACK when the file is unreadable."""
    try:
        return (path or directives_path()).read_text(encoding="utf-8")
    except Exception:
        return FALLBACK


def save_directives(text: str, path: Path | None = None) -> Path:
    """Atomically write the directives and return the path.

    Raises ValueError when the text is empty — an empty system prompt would
    silently turn the assistant feral, so it must never reach disk.
    """
    p = path or directives_path()
    if not text.strip():
        raise ValueError("Core directives cannot be empty.")
    p.parent.mkdir(parents=True, exist_ok=True)

    # Keep the previous version as prompt.bak (best effort — a failed backup
    # must not block the save).
    try:
        if p.exists():
            p.with_suffix(".bak").write_bytes(p.read_bytes())
    except Exception:
        pass

    # Normalise to CRLF to match the shipped prompt.txt (line endings the
    # editor never preserves on its own), then swap atomically.
    data = text.replace("\r\n", "\n").replace("\r", "\n")
    data = data.replace("\n", "\r\n").encode("utf-8")

    tmp = p.with_name(p.name + ".tmp")
    tmp.write_bytes(data)
    os.replace(tmp, p)
    return p
