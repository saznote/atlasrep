"""
core/user_paths.py — Cross‑platform user directory resolution + safe mkdir.

Two problems this module solves:
──────────────────────────────────
1.  ~/Desktop may not exist or may be a redirected/managed folder (OneDrive
    "Known Folder Move" on Windows, localized XDG names on Linux, etc.).
2.  mkdir() calls raise PermissionError / OSError when the app lacks write
    access (enterprise‑managed home, read‑only mount, sandboxed environment).

Usage
─────
    from core.user_paths import get_desktop, safe_mkdir

    desk = get_desktop()
    path = safe_mkdir(desk / "MyFolder", fallback=Path.home() / "MyFolder")
"""

import os
import platform
import subprocess
from pathlib import Path

__all__ = ["get_desktop", "get_documents", "get_downloads",
           "safe_mkdir", "ensure_dir"]

_OS = platform.system()


# ══════════════════════════════════════════════════════════════════════
#  Public helpers
# ══════════════════════════════════════════════════════════════════════

def get_desktop() -> Path:
    """
    Return the user's real Desktop directory.

    Strategy (same as ui.py:SettingsBar._get_desktop_dir):
        Windows  → SHGetKnownFolderPath(FOLDERID_Desktop), then registry.
        Linux    → xdg-user-dir, then ~/.config/user-dirs.dirs.
        macOS    → ~/Desktop (display‑only localisation, real path is fixed).
    Falls back to ``~/Desktop`` when all else fails.
    """
    return _resolve_known_folder("Desktop")


def get_documents() -> Path:
    """Return the real Documents directory (same resolution strategy)."""
    return _resolve_known_folder("Documents")


def get_downloads() -> Path:
    """Return the real Downloads directory (same resolution strategy)."""
    return _resolve_known_folder("Downloads")


def safe_mkdir(path: Path, *fallbacks: Path,
               exist_ok: bool = True) -> Path:
    """
    Try to create *path*; on PermissionError/OSError try each *fallbacks*
    in order.  Return whichever directory was successfully created (or
    already existed).  Raise OSError only when **all** attempts fail.

    Example
    -------
        data_dir = safe_mkdir(
            Path.home() / "Desktop" / "AppData",
            Path.home() / "Documents" / "AppData",
            Path.home() / ".app_data",
        )
    """
    for candidate in (path, *fallbacks):
        try:
            candidate.mkdir(parents=True, exist_ok=exist_ok)
            return candidate
        except (OSError, PermissionError):
            continue
    raise OSError(
        f"Cannot create any of the following directories — check permissions:\n"
        + "\n".join(f"  • {p}" for p in (path, *fallbacks))
    )


def ensure_dir(path: Path) -> Path:
    """
    Like ``path.mkdir(parents=True, exist_ok=True)`` but raises a
    human‑readable ``OSError`` that includes the path, instead of a raw
    exception.  No fallback — use :func:`safe_mkdir` when you want one.
    """
    try:
        path.mkdir(parents=True, exist_ok=True)
        return path
    except PermissionError:
        raise OSError(
            f"Permission denied: cannot create directory at '{path}'. "
            f"Try a location under your home directory."
        )
    except OSError:
        raise OSError(
            f"Cannot create directory at '{path}'. "
            f"Check that the parent directory exists and is writable."
        )


# ══════════════════════════════════════════════════════════════════════
#  Internal helpers
# ══════════════════════════════════════════════════════════════════════

_FOLDER_GUIDS = {
    "Desktop":   "B4BFCC3A-DB2C-424C-B029-7FE99A87C641",
    "Documents": "FDD39AD0-238F-46AF-ADB4-6C85480369C7",
    "Downloads": "374DE290-123F-4565-9164-39C4925E467B",
}

_REVERSE_KNOWN_NAMES = {
    "Desktop":   "DESKTOP",
    "Documents": "DOCUMENTS",
    "Downloads": "DOWNLOAD",
}


def _resolve_known_folder(name: str) -> Path:
    """
    Resolve *name* (Desktop / Documents / Downloads) using platform‑specific
    APIs.  Falls back to ``~/<name>``.
    """
    home = Path.home()

    if _OS == "Windows":
        return _win_known_folder(name) or home / name

    if _OS == "Linux":
        p = _linux_xdg_folder(name)
        if p is not None:
            return p
        return home / name

    # macOS — Desktop / Documents / Downloads are always at ~/<name>
    return home / name


# ── Windows ──────────────────────────────────────────────────────────

def _win_known_folder(name: str) -> Path | None:
    """Try SHGetKnownFolderPath and then the registry."""
    guid_str = _FOLDER_GUIDS.get(name)
    if guid_str is None:
        return None

    # 1) SHGetKnownFolderPath
    p = _win_shget(guid_str)
    if p is not None:
        return p

    # 2) Registry: User Shell Folders
    p = _win_registry(name)
    if p is not None:
        return p

    return None


def _win_shget(guid_str: str) -> Path | None:
    try:
        import ctypes
        from ctypes import wintypes

        parts = guid_str.split("-")
        data1 = int(parts[0], 16)
        data2 = int(parts[1], 16)
        data3 = int(parts[2], 16)
        data4_bytes = bytes.fromhex(parts[3] + parts[4])

        class _GUID(ctypes.Structure):
            _fields_ = [("Data1", wintypes.DWORD),
                        ("Data2", wintypes.WORD),
                        ("Data3", wintypes.WORD),
                        ("Data4", ctypes.c_ubyte * 8)]

        fid = _GUID(data1, data2, data3,
                    (ctypes.c_ubyte * 8)(*data4_bytes))
        buf = ctypes.c_wchar_p()
        if ctypes.windll.shell32.SHGetKnownFolderPath(
                ctypes.byref(fid), 0, None, ctypes.byref(buf)) == 0:
            p = Path(buf.value)
            ctypes.windll.ole32.CoTaskMemFree(buf)
            if p.is_dir():
                return p
    except Exception:
        pass
    return None


def _win_registry(name: str) -> Path | None:
    try:
        import winreg
        with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion"
                r"\Explorer\User Shell Folders") as key:
            val, _ = winreg.QueryValueEx(key, name)
        p = Path(os.path.expandvars(val))
        if p.is_dir():
            return p
    except Exception:
        pass
    return None


# ── Linux ────────────────────────────────────────────────────────────

def _linux_xdg_folder(name: str) -> Path | None:
    """Try ``xdg-user-dir <FOLDER>`` then parse ``~/.config/user-dirs.dirs``."""
    xdg_var = _REVERSE_KNOWN_NAMES.get(name)
    if xdg_var is None:
        return None

    # a) xdg-user-dir binary
    p = _linux_xdg_binary(xdg_var)
    if p is not None:
        return p

    # b) ~/.config/user-dirs.dirs
    p = _linux_xdg_config(name, xdg_var)
    if p is not None:
        return p

    return None


def _linux_xdg_binary(xdg_var: str) -> Path | None:
    try:
        out = subprocess.run(["xdg-user-dir", xdg_var],
                             capture_output=True, text=True, timeout=5)
        p = Path(out.stdout.strip())
        if out.stdout.strip() and p != Path.home() and p.is_dir():
            return p
    except Exception:
        pass
    return None


def _linux_xdg_config(name: str, xdg_var: str) -> Path | None:
    home = Path.home()
    try:
        cfg = home / ".config" / "user-dirs.dirs"
        for line in cfg.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith(f"XDG_{xdg_var}_DIR"):
                val = line.split("=", 1)[1].strip().strip('"')
                p = Path(val.replace("$HOME", str(home)))
                if p != home and p.is_dir():
                    return p
    except Exception:
        pass
    return None