# Project Context — MARK LIII

> This file is a working context document for AI coding assistants and contributors.
> Read it before modifying the codebase. The authoritative user-facing docs are in
> `readme.md`.

## 1. What this project is

**MARK LIII (protocol 53)** is a cross-platform, hands-free personal AI assistant
("JARVIS") by FatihMakes. It talks in real time over the **Gemini Live API**
(`gemini-3.1-flash-live-preview`), can hear (mic streaming, optional local
"Hey Jarvis" wake word), see (screen + camera capture piped into the session),
and act on the computer through a registry of self-describing **actions** and
drop-in **plugins**.

Key behaviours:

- Wake word "Hey Jarvis" (opt-in, `openwakeword`); auto-sleep after 2 min of
  silence (`WAKE_SLEEP_TIMEOUT = 120.0` in `main.py`); mic is not streamed
  while asleep.
- Instant acknowledgment in the user's language when a longer tool starts.
- Recallable long-term memory: full store on disk, prompt carries a budgeted
  core + key index; on-demand lookup via `recall_memory` (local search, no
  second model).
- Undo of the last assistant action (files, settings) — `core/undo.py`.
- Irreversible actions (shutdown, restart, WiFi) require a real user button —
  `core/confirm.py`.
- Remote dashboard (phone control) via FastAPI — `dashboard/`.

## 2. Tech stack

- **Python** (3.10+ compatible, uses `BaseExceptionGroup` guard), no framework
  pin beyond `requirements.txt`.
- **PyQt6** — the entire HUD (`ui.py`).
- **google-genai** (`google.genai`) — Gemini Live API streaming session, tools,
  voices, session resumption.
- **sounddevice + numpy** — 16-bit PCM mic capture at 16 kHz, playback at 24 kHz.
- **Playwright** — browser automation; **pyautogui / pyperclip / pygetwindow**
  — OS input control; **psutil, mss, opencv, pillow** — system & vision.
- **FastAPI + uvicorn** — remote dashboard.
- Windows-only extras are pip-markered (`sys_platform == "win32"`); macOS/Linux
  OS actions shell out to native tools (`pactl`, `brightnessctl`, `osascript`,
  `systemd-run`, `xdg-open`).
