#!/bin/bash
# ── Sarra — lanceur Mark-LIII ────────────────────────────────────────────────
# Called by the desktop shortcut "Sarra". Prevents a double launch: if an
# instance is already running it just notifies and exits.
APP_DIR="/data/usershare/Mark-LIII-main"
LOG="/tmp/qpp-run.log"

if pgrep -f "python3.*main\.py" >/dev/null 2>&1; then
    notify-send "Sarra" "Sarra est déjà en cours d'exécution." 2>/dev/null || true
    exit 0
fi

cd "$APP_DIR" || exit 1
nohup python3 -u main.py >> "$LOG" 2>&1 &
disown
notify-send "Sarra" "Démarrage de Sarra…" 2>/dev/null || true
exit 0
